package com.quarkdown.interaction.os

object OsUtils {
    /**
     * The name of the current operating system.
     */
    private val osName: String by lazy { System.getProperty("os.name").lowercase() }

    /**
     * @return whether the current operating system is Windows
     */
    private fun isWindows(): Boolean = "win" in osName

    /**
     * @return whether the current operating system is Unix-like
     */
    private fun isUnix(): Boolean = "nix" in osName || "nux" in osName || "mac" in osName

    /**
     * Runs the given [windows] or [unix] function depending on the current operating system.
     * @return the result of the function based on the OS
     */
    fun <T> dependent(
        windows: () -> T,
        unix: () -> T,
    ) = when {
        isWindows() -> windows()
        isUnix() -> unix()
        else -> throw UnsupportedOperationException("Unexpected OS: $osName")
    }
}
