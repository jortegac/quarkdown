package com.quarkdown.rendering.html.extension

import com.quarkdown.core.context.Context
import com.quarkdown.core.document.sub.Subdocument
import com.quarkdown.core.flavor.RendererFactory
import com.quarkdown.core.rendering.RenderingComponents
import com.quarkdown.rendering.html.HtmlExportOptions
import com.quarkdown.rendering.html.post.HtmlPostRenderer
import com.quarkdown.rendering.html.post.HtmlSubdocumentPostRenderer

/**
 * The HTML rendering plug-in produces a browser-compatible document.
 *
 * - The root document comes with a full export which includes themes and scripts, and possibly media resources.
 * - Other subdocuments are exported to lightweight subdirectories, with possibly media resources.
 */
fun RendererFactory.html(
    context: Context,
    options: HtmlExportOptions = HtmlExportOptions(),
) = RenderingComponents(
    nodeRenderer = accept(HtmlRendererFactoryVisitor(context)),
    postRenderer =
        when (context.subdocument) {
            Subdocument.Root -> HtmlPostRenderer(context, options.resourcesLayout)
            else -> HtmlSubdocumentPostRenderer(context)
        },
)
