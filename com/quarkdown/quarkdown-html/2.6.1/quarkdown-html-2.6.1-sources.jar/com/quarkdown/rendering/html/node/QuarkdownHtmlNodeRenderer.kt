package com.quarkdown.rendering.html.node

import com.quarkdown.core.ast.AstGroup
import com.quarkdown.core.ast.Node
import com.quarkdown.core.ast.attributes.id.Identifiable
import com.quarkdown.core.ast.attributes.id.getId
import com.quarkdown.core.ast.attributes.localization.LocalizedKind
import com.quarkdown.core.ast.attributes.location.LocationTrackableNode
import com.quarkdown.core.ast.attributes.location.getLocationLabel
import com.quarkdown.core.ast.attributes.reference.getCitationLabel
import com.quarkdown.core.ast.attributes.reference.getDefinition
import com.quarkdown.core.ast.base.TextNode
import com.quarkdown.core.ast.base.block.BlockQuote
import com.quarkdown.core.ast.base.block.Code
import com.quarkdown.core.ast.base.block.Heading
import com.quarkdown.core.ast.base.block.Paragraph
import com.quarkdown.core.ast.base.block.Table
import com.quarkdown.core.ast.base.block.isMarker
import com.quarkdown.core.ast.base.block.list.ListBlock
import com.quarkdown.core.ast.base.inline.CodeSpan
import com.quarkdown.core.ast.base.inline.CriticalContent
import com.quarkdown.core.ast.base.inline.Text
import com.quarkdown.core.ast.quarkdown.CaptionableNode
import com.quarkdown.core.ast.quarkdown.FunctionCallNode
import com.quarkdown.core.ast.quarkdown.bibliography.BibliographyCitation
import com.quarkdown.core.ast.quarkdown.bibliography.BibliographyView
import com.quarkdown.core.ast.quarkdown.block.Box
import com.quarkdown.core.ast.quarkdown.block.Clipped
import com.quarkdown.core.ast.quarkdown.block.Collapse
import com.quarkdown.core.ast.quarkdown.block.Container
import com.quarkdown.core.ast.quarkdown.block.Figure
import com.quarkdown.core.ast.quarkdown.block.FileTree
import com.quarkdown.core.ast.quarkdown.block.FileTreeEntry
import com.quarkdown.core.ast.quarkdown.block.Landscape
import com.quarkdown.core.ast.quarkdown.block.Math
import com.quarkdown.core.ast.quarkdown.block.MermaidDiagram
import com.quarkdown.core.ast.quarkdown.block.NavigationContainer
import com.quarkdown.core.ast.quarkdown.block.Numbered
import com.quarkdown.core.ast.quarkdown.block.PageBreak
import com.quarkdown.core.ast.quarkdown.block.SlidesFragment
import com.quarkdown.core.ast.quarkdown.block.SlidesSpeakerNote
import com.quarkdown.core.ast.quarkdown.block.Stacked
import com.quarkdown.core.ast.quarkdown.block.SubdocumentGraph
import com.quarkdown.core.ast.quarkdown.block.list.FocusListItemVariant
import com.quarkdown.core.ast.quarkdown.block.list.LocationTargetListItemVariant
import com.quarkdown.core.ast.quarkdown.block.list.TableOfContentsItemVariant
import com.quarkdown.core.ast.quarkdown.block.toc.TableOfContentsView
import com.quarkdown.core.ast.quarkdown.block.toc.convertTableOfContentsToListNode
import com.quarkdown.core.ast.quarkdown.inline.IconImage
import com.quarkdown.core.ast.quarkdown.inline.InlineCollapse
import com.quarkdown.core.ast.quarkdown.inline.Keybinding
import com.quarkdown.core.ast.quarkdown.inline.LastHeading
import com.quarkdown.core.ast.quarkdown.inline.MathSpan
import com.quarkdown.core.ast.quarkdown.inline.PageCounter
import com.quarkdown.core.ast.quarkdown.inline.TextTransform
import com.quarkdown.core.ast.quarkdown.inline.TextTransformData
import com.quarkdown.core.ast.quarkdown.inline.Whitespace
import com.quarkdown.core.ast.quarkdown.invisible.PageMarginContentInitializer
import com.quarkdown.core.ast.quarkdown.invisible.PageNumberFormatter
import com.quarkdown.core.ast.quarkdown.invisible.PageNumberReset
import com.quarkdown.core.ast.quarkdown.invisible.SlidesConfigurationInitializer
import com.quarkdown.core.ast.quarkdown.reference.CrossReference
import com.quarkdown.core.ast.quarkdown.reference.CrossReferenceableNode
import com.quarkdown.core.ast.quarkdown.reference.linkableReferenceId
import com.quarkdown.core.context.Context
import com.quarkdown.core.context.localization.localizeOrNull
import com.quarkdown.core.context.options.shouldAutoPageBreak
import com.quarkdown.core.context.subdocument.subdocumentGraph
import com.quarkdown.core.document.sub.Subdocument
import com.quarkdown.core.rendering.tag.buildMultiTag
import com.quarkdown.core.rendering.tag.buildTag
import com.quarkdown.core.rendering.tag.tagBuilder
import com.quarkdown.core.util.Escape
import com.quarkdown.core.util.kebabCaseName
import com.quarkdown.rendering.html.HtmlIdentifierProvider
import com.quarkdown.rendering.html.HtmlIdentifierProvider.Companion.sanitizeId
import com.quarkdown.rendering.html.HtmlTagBuilder
import com.quarkdown.rendering.html.css.asCSS
import com.quarkdown.rendering.html.css.textTransform

/**
 * A renderer for Quarkdown ([com.quarkdown.core.flavor.quarkdown.QuarkdownFlavor]) nodes that exports their content into valid HTML code.
 * @param context additional information produced by the earlier stages of the pipeline
 */
class QuarkdownHtmlNodeRenderer(
    context: Context,
) : BaseHtmlNodeRenderer(context) {
    private val helper = HtmlRendererHelper(this, context)

    /**
     * A `<div class="styleClass">...</div>` tag.
     */
    private fun div(
        styleClass: String? = null,
        init: HtmlTagBuilder.() -> Unit,
    ) = tagBuilder("div", init = init)
        .className(styleClass)
        .build()

    /**
     * A `<div class="styleClass">children</div>` tag.
     */
    private fun div(
        styleClass: String,
        children: List<Node>,
    ) = div(styleClass) { +children }

    // Quarkdown node rendering

    // The function was already expanded by previous stages: its output nodes are stored in its children.
    override fun visit(node: FunctionCallNode): CharSequence = visit(AstGroup(node.children))

    // Block

    override fun visit(node: Figure<*>) =
        buildTag("figure") {
            helper.captionedContent(this, node, positionProvider = { figures }) {
                +node.child
            }
        }

    // An empty div that acts as a page break.
    override fun visit(node: PageBreak) =
        tagBuilder("div")
            .className("page-break")
            .hidden()
            .build()

    override fun visit(node: Math) =
        buildTag("formula") {
            +node.expression
            attribute("data-block", "")
            optionalAttribute("id", node.linkableReferenceId?.let(::sanitizeId))
            optionalAttribute("data-location", node.getLocationLabel(context))
            style(node.style)
        }

    override fun visit(node: Container) =
        buildTag("div") {
            classNames(
                "container",
                "fullwidth".takeIf { node.fullWidth },
                "float".takeIf { node.float != null },
                "full-column-span".takeIf { node.fullColumnSpan },
                node.className,
            )

            +node.children

            style(node.style) {
                "width" value node.width
                "height" value node.height
                "float" value node.float
            }
        }

    override fun visit(node: Stacked) =
        div("stack stack-${node.layout.asCSS}") {
            +node.children

            style {
                (node.layout as? Stacked.Grid)?.let {
                    // The amount of 'auto' matches the amount of columns/rows.
                    "grid-template-columns" value "auto ".repeat(it.columnCount).trimEnd()
                }

                "justify-content" value node.mainAxisAlignment
                "align-items" value node.crossAxisAlignment
                "row-gap" value node.rowGap
                "column-gap" value node.columnGap
            }
        }

    override fun visit(node: Numbered): CharSequence {
        val id = node.linkableReferenceId?.let(::sanitizeId)
        return if (id != null) {
            buildTag("div") {
                attribute("id", id)
                +node.children
            }
        } else {
            buildMultiTag {
                +node.children
            }
        }
    }

    override fun visit(node: Landscape) = div("landscape", node.children)

    override fun visit(node: Clipped) =
        div("clip clip-${node.clip.asCSS}") {
            +Container(children = node.children)
        }

    override fun visit(node: Box) =
        div {
            classNames("box", node.type.asCSS)

            if (node.title != null) {
                tag("header") {
                    tag("h4", node.title!!)

                    style {
                        "color" value node.foregroundColor // Must be repeated to force override.
                        "padding" value node.padding
                    }
                }
            }

            // Box actual content.
            +div("box-content") {
                +node.content

                style { "padding" value node.padding }
            }

            // Box style. Padding is applied separately to the header and the content.
            style {
                "background-color" value node.backgroundColor
                "color" value node.foregroundColor
            }
        }

    override fun visit(node: Collapse) =
        buildTag("details") {
            if (node.isOpen) {
                attribute("open", "")
            }

            tag("summary") { +node.title }
            +node.content
        }

    override fun visit(node: Whitespace) =
        buildTag(if (node.isBlock) "div" else "span") {
            className("whitespace")
            val hasSize = node.width != null || node.height != null
            if (!hasSize) {
                +"&nbsp;"
            }
            style {
                "width" value node.width
                "height" value node.height
            }
        }

    override fun visit(node: NavigationContainer) =
        buildTag("nav") {
            optionalAttribute("role", node.role?.asCSS)
            optionalAttribute("data-role", node.role?.kebabCaseName)
            +node.children
        }

    override fun visit(node: TableOfContentsView): CharSequence {
        val tableOfContents = context.attributes.tableOfContents ?: return ""

        val tree: ListBlock =
            convertTableOfContentsToListNode(
                node,
                this@QuarkdownHtmlNodeRenderer,
                tableOfContents.items,
                linkUrlMapper = { item ->
                    "#" + HtmlIdentifierProvider.of(this@QuarkdownHtmlNodeRenderer, context).getId(item.target)
                },
            )

        return NavigationContainer(
            role = NavigationContainer.Role.TABLE_OF_CONTENTS,
            listOf(tree),
        ).accept(this)
    }

    override fun visit(node: BibliographyView) =
        buildTag("div") {
            classNames("bibliography", "bibliography-${node.style.name}")
            node.bibliography.entries.values.mapIndexed { index, entry ->
                tag("span") {
                    className("bibliography-entry-label")
                    +node.style.labelProvider.getListLabel(entry, index)
                }
                tag("span") {
                    className("bibliography-entry-content")
                    +node.style.contentOf(entry)
                }
            }
        }

    override fun visit(node: MermaidDiagram) =
        buildTag("pre") {
            classNames("mermaid")
            +escapeCriticalContent(node.code)
        }

    override fun visit(node: FileTree): CharSequence =
        buildTag("div") {
            className("file-tree")

            fun buildEntries(entries: List<FileTreeEntry>): CharSequence =
                buildTag("ul") {
                    entries.forEach { entry ->
                        tag("li") {
                            when (entry) {
                                is FileTreeEntry.File -> {
                                    className("file")
                                    attribute("data-name", escapeCriticalContent(entry.name))
                                    +CriticalContent(entry.name)
                                }

                                is FileTreeEntry.Directory -> {
                                    className("directory")
                                    attribute("data-name", escapeCriticalContent(entry.name))
                                    +CriticalContent(entry.name)
                                    +buildEntries(entry.entries)
                                }

                                is FileTreeEntry.Ellipsis -> {
                                    className("ellipsis")
                                    +"&hellip;"
                                }
                            }
                            if (entry.highlighted) {
                                attribute("data-highlighted", "")
                            }
                        }
                    }
                }
            +buildEntries(node.entries)
        }

    override fun visit(node: SubdocumentGraph): CharSequence {
        fun id(subdocument: Subdocument) = subdocument.name.hashCode()

        val content =
            "graph LR\n" +
                context.subdocumentGraph.edges.joinToString("\n") { edge ->
                    val from = edge.first
                    val to = edge.second
                    val (idFrom, idTo) = id(from) to id(to)
                    val (nameFrom, nameTo) = from.name to to.name

                    "$idFrom[\"$nameFrom\"] --> $idTo[\"$nameTo\"]"
                }

        return MermaidDiagram(content).accept(this)
    }

    // Inline

    override fun visit(node: MathSpan) =
        buildTag("formula") {
            +node.expression
            style(node.style)
        }

    override fun visit(node: CrossReference): CharSequence {
        val definition: CrossReferenceableNode = node.getDefinition(context) ?: return Text("[???]").accept(this)

        // The target node could have an ID. If so, the reference is a link to that node.
        // Headings use Identifiable for auto-generated IDs; other nodes use their referenceId directly.
        val anchorId =
            (definition as? Identifiable)?.accept(HtmlIdentifierProvider.of(this, context))
                ?: definition.linkableReferenceId?.let(::sanitizeId)

        val reference =
            buildTag("span") {
                className("cross-reference")

                when (definition) {
                    is LocationTrackableNode if definition.getLocationLabel(context) != null -> {
                        helper.withLocationLabel(this, definition)
                    }

                    // If no label is available, use the caption if possible.
                    is CaptionableNode if definition.caption != null -> {
                        +definition.caption!!
                    }

                    // Fallback: use the target's text if possible.
                    is TextNode -> {
                        +definition.text
                    }

                    // Fallback: raw reference ID, escaped for safe HTML output.
                    else -> {
                        +escapeCriticalContent(node.referenceId)
                    }
                }
                if (definition is LocalizedKind) {
                    helper.withLocalizedKind(this, definition)
                }
            }

        return when (anchorId) {
            null -> {
                reference
            }

            // No linkable ID.
            else -> {
                buildTag("a") {
                    // ID available: link to the target.
                    attribute("href", "#$anchorId")
                    +reference
                }
            }
        }
    }

    override fun visit(node: BibliographyCitation): CharSequence {
        val label = node.getCitationLabel(context) ?: return Text("[???]").accept(this)
        return Text(label).accept(this)
    }

    override fun visit(node: SlidesFragment) =
        tagBuilder("div", node.children)
            .classNames("fragment", node.behavior.asCSS)
            .build()

    override fun visit(node: SlidesSpeakerNote) =
        buildTag("aside") {
            className("notes")
            hidden()
            +node.children
        }

    override fun visit(node: TextTransform): CharSequence {
        val tagName =
            when (node.data.script) {
                TextTransformData.Script.SUB -> "sub"
                TextTransformData.Script.SUP -> "sup"
                null -> "span"
            }

        return buildTag(tagName) {
            className(node.className)
            +node.children
            style { textTransform(node.data) }
        }
    }

    override fun visit(node: IconImage): CharSequence =
        buildTag("i") {
            val name = Escape.Html.escape(node.name)
            classNames("icon-image", "bi", "bi-$name")
            attribute("aria-hidden", "true")
        }

    override fun visit(node: InlineCollapse) =
        buildTag("span") {
            // Dynamic behavior is handled by JS.
            className("inline-collapse")
            attribute("data-full-text", buildMultiTag { +node.text })
            attribute("data-collapsed-text", buildMultiTag { +node.placeholder })
            attribute("data-collapsed", !node.isOpen)
            +if (node.isOpen) node.text else node.placeholder
        }

    override fun visit(node: Keybinding) =
        buildTag("span") {
            className("keybinding")
            node.parts.forEach { part ->
                +buildTag("kbd") {
                    +part.displayName
                    optionalAttribute(
                        "data-mac",
                        part.macDisplayName.takeIf { it != part.displayName },
                    )
                }
            }
        }

    // Invisible nodes

    override fun visit(node: PageMarginContentInitializer) =
        // In slides and paged documents, these elements are copied to each page in post-processing.
        buildTag("div") {
            classNames(
                "page-margin-content",
                "page-margin-${node.position.asCSS}",
            )
            attribute("data-on-left-page", node.position.forLeftPage.asCSS)
            attribute("data-on-right-page", node.position.forRightPage.asCSS)
            +node.children
        }

    override fun visit(node: PageNumberReset) =
        buildTag("div") {
            className("page-number-reset")
            attribute("data-start", node.startFrom)
            hidden()
        }

    override fun visit(node: PageNumberFormatter) =
        buildTag("div") {
            className("page-number-formatter")
            attribute("data-format", node.format)
            hidden()
        }

    override fun visit(node: PageCounter) =
        // The current or total page number.
        // The actual number is filled by a script at runtime
        // (either slides.js or paged.js, depending on the document type).
        buildTag("span") {
            +"-" // The default placeholder in case it is not filled by a script (e.g. plain documents).
            className(
                when (node.target) {
                    PageCounter.Target.CURRENT -> "current-page-number"
                    PageCounter.Target.TOTAL -> "total-page-number"
                },
            )
        }

    override fun visit(node: LastHeading) =
        buildTag("span") {
            // Since pagination is performed at runtime, the last heading must be retrieved at runtime as well.
            className("last-heading")
            attribute("data-depth", node.depth)
        }

    override fun visit(node: SlidesConfigurationInitializer): CharSequence =
        buildTag("script") {
            hidden()
            // Injects properties that are read at runtime after the document is loaded.
            +buildString {
                append("window.slidesConfig = {")
                node.centerVertically?.let {
                    append("center: $it,")
                }
                node.showControls?.let {
                    append("showControls: $it,")
                }
                node.showNotes?.let {
                    append("showNotes: $it,")
                }
                node.transition?.let {
                    append("transitionStyle: '${it.style.asCSS}',")
                    append("transitionSpeed: '${it.speed.asCSS}',")
                }
                append("};")
            }
        }

    // Additional behavior of base nodes

    // On top of the default behavior, an anchor ID is set,
    // and it could force an automatic page break if suitable.
    override fun visit(node: Heading): String {
        val tagBuilder =
            when {
                // When a heading has a depth of 0 (achievable only via functions), it is an invisible marker with an ID.
                node.isMarker -> {
                    tagBuilder("div") {
                        className("marker")
                        hidden()
                    }
                }

                // Regular headings.
                else -> {
                    tagBuilder("h${node.depth}", node.text)
                }
            }

        // The heading tag itself.
        return tagBuilder
            .className("page-break".takeIf { context.shouldAutoPageBreak(node) })
            .optionalAttribute(
                "id",
                // Generate an automatic identifier if allowed by settings.
                HtmlIdentifierProvider
                    .of(renderer = this, context = context)
                    .takeIf { context.options.enableAutomaticIdentifiers || node.customId != null }
                    ?.getId(node),
            ).optionalAttribute("data-decorative", "".takeIf { node.isDecorative })
            .let { helper.withLocationLabel(it, node) }
            .style(node.style)
            .build()
    }

    // On top of the base behavior, a blockquote can have a type and an attribution.
    override fun visit(node: BlockQuote) =
        buildTag("blockquote") {
            // If the quote has a type (e.g. TIP),
            // the whole quote is marked as a 'tip' blockquote
            // and a localized label is shown (e.g. 'Tip:' for English).
            node.type?.asCSS?.let { type ->
                className(type)
                // The type is associated to a localized label
                // only if the document language is set and the set language is supported.
                context.localizeOrNull(key = type)?.let { localizedLabel ->
                    // The localized label is set as a CSS variable.
                    // Themes can customize label appearance and formatting.
                    style { "--quote-type-label" value "'$localizedLabel'" }
                    // The quote is marked as labeled to allow further customization.
                    attribute("data-labeled", "")
                }
            }

            // If the quote has a type, the first child must be a paragraph, because the label is rendered as ::before.
            if (node.type != null && node.content.firstOrNull() !is Paragraph) {
                +tagBuilder("p").acceptEmpty().build()
            }

            +node.content
            node.attribution?.let {
                +tagBuilder("p", it).className("attribution").build()
            }
        }

    // Quarkdown introduces table captions, also numerated.
    override fun visit(node: Table) =
        buildTag("table") {
            helper.captionedContent(this, node, positionProvider = { tables }, captionTagName = "caption") {
                tableContent(node)
            }
        }

    /**
     * Whether a rendered [Code] block must be wrapped in a `<figure>` tag hosting its caption:
     * that is, when the block is numbered, captioned, or referenceable via a cross-reference.
     */
    private val Code.requiresFigure: Boolean
        get() = caption != null || getLocationLabel(context) != null || linkableReferenceId != null

    /**
     * Builds the list of callout descriptions displayed below a code block,
     * with each item numbered to match the marker attached to its corresponding line of code.
     * @param callouts callout contents, in marker order
     * @return the `ul.code-callouts` tag
     */
    private fun calloutList(callouts: Collection<String>) =
        buildTag("ul") {
            className("code-callouts")
            callouts.forEachIndexed { index, content ->
                tag("li") {
                    className("code-callout")
                    tag("span") {
                        className("code-callout-marker")
                        +(index + 1).toString()
                    }
                    +escapeCriticalContent(content)
                }
            }
        }

    override fun visit(node: Code): String {
        val block = super.visit(node)
        val code =
            if (node.requiresFigure) {
                buildTag("figure") {
                    helper.captionedContent(this, node, positionProvider = { codeBlocks }) {
                        +block
                    }
                }
            } else {
                block
            }

        if (node.callouts.isEmpty()) return code

        return buildMultiTag {
            +code
            +calloutList(node.callouts.values)
        }
    }

    // A code span can contain additional content, such as a color preview.
    override fun visit(node: CodeSpan): String {
        val codeTag = super.visit(node)

        // The code is wrapped to allow additional content.
        return buildTag("span") {
            className("codespan-content")

            +codeTag

            when (val content = node.content) {
                null -> {}

                // No additional content.
                is CodeSpan.ColorContent -> {
                    // If the code contains a color code, show the color preview.
                    +buildTag("span") {
                        style { "background-color" value content.color }
                        className("color-preview")
                    }
                }
            }
        }
    }

    // List item variants.

    override fun visit(variant: FocusListItemVariant): HtmlTagBuilder.() -> Unit =
        {
            if (variant.isFocused) {
                className("focused")
            }
        }

    override fun visit(variant: LocationTargetListItemVariant): HtmlTagBuilder.() -> Unit =
        {
            helper.withLocationLabel(this, variant.target)
        }

    override fun visit(variant: TableOfContentsItemVariant): HtmlTagBuilder.() -> Unit =
        {
            attribute(
                "data-target-id",
                HtmlIdentifierProvider.of(this@QuarkdownHtmlNodeRenderer, context).getId(variant.item.target),
            )
            attribute("data-depth", variant.item.depth.toString())
        }
}
