@file:QModule

package com.quarkdown.stdlib

import com.quarkdown.core.ast.AstGroup
import com.quarkdown.core.ast.base.block.Html
import com.quarkdown.core.ast.quarkdown.block.Markdown
import com.quarkdown.core.context.Context
import com.quarkdown.core.context.MutableContext
import com.quarkdown.core.context.options.HtmlOptions
import com.quarkdown.core.context.options.merge
import com.quarkdown.core.document.sub.Subdocument
import com.quarkdown.core.document.sub.getOutputFileName
import com.quarkdown.core.function.reflect.annotation.Body
import com.quarkdown.core.function.reflect.annotation.Injected
import com.quarkdown.core.function.reflect.annotation.LikelyBody
import com.quarkdown.core.function.value.NodeValue
import com.quarkdown.core.function.value.Value
import com.quarkdown.core.function.value.VoidValue
import com.quarkdown.core.function.value.wrappedAsValue
import com.quarkdown.core.permissions.Permission
import com.quarkdown.core.permissions.requirePermission
import com.quarkdown.core.util.Escape
import com.quarkdown.processor.annotation.Name
import com.quarkdown.processor.annotation.QFunction
import com.quarkdown.processor.annotation.QModule
import com.quarkdown.stdlib.internal.applyImportantToCSS

/**
 * Configures HTML generation options.
 *
 * ```markdown
 * .htmloptions baseurl:{https://example.com} title:{My Page}
 * ```
 *
 * Successive calls to this function merge with the previous options.
 *
 * @param baseUrl the base URL to use for resolving relative paths in the generated HTML, e.g. `https://example.com`.
 *                Trailing slashes are automatically ignored.
 *                If specified, a canonical link is set in the HTML's `<head>` and the sitemap is generated.
 * @param title overrides the document name used in the HTML `<title>` tag.
 *              If unspecified, the document name (set via `.docname`) is used.
 * @wiki html-options
 */
@QFunction
@Name("htmloptions")
fun htmlOptions(
    @Injected context: MutableContext,
    @Name("baseurl") baseUrl: String? = null,
    title: String? = null,
) = VoidValue.also {
    context.options.html =
        HtmlOptions(
            baseUrl = baseUrl?.trimEnd('/'),
            title = title,
        ).merge(context.options.html)
}

/**
 * Creates an HTML element, which is rendered as-is without any additional processing or escaping,
 * as long as the rendering target supports HTML.
 *
 * ```html
 * .html
 *     <div class="my-container">
 *       My HTML container
 *     </div>
 * ```
 *
 * ```markdown
 * **Hello** .html {<em>world</em>}!
 * ```
 *
 * @param content raw HTML content to inject
 * @return a new [Html] node
 * @permission [Permission.NativeContent] to inject native HTML content
 * @throws com.quarkdown.core.permissions.MissingPermissionException if [Permission.NativeContent] is not granted
 * @wiki html
 */
@QFunction
fun html(
    @Injected context: Context,
    @LikelyBody content: String,
): NodeValue {
    context.requirePermission(
        Permission.NativeContent,
        message = "Cannot inject native HTML content",
    )
    return Html(content).wrappedAsValue()
}

/**
 * Creates a `<style>` HTML element with the provided CSS content.
 * The content is wrapped in a `<style>` tag and rendered as-is,
 * without any additional processing or escaping, as long as the rendering target supports HTML.
 *
 * Each CSS property value automatically has `!important` applied to it,
 * unless it already has it.
 *
 * ```css
 * .css
 *   body {
 *     background-color: green;
 *   }
 * ```
 *
 * @param content raw CSS content to inject
 * @return a new [Html] node representing the style element
 * @permission [Permission.NativeContent] to inject native CSS content
 * @throws com.quarkdown.core.permissions.MissingPermissionException if [Permission.NativeContent] is not granted
 * @see [cssProperties] for a more structured way to override CSS properties.
 * @wiki css
 */
@QFunction
fun css(
    @Injected context: Context,
    @LikelyBody content: String,
) = html(
    context,
    "<style data-hidden=\"\">${applyImportantToCSS(content)}</style>",
)

private const val CSS_ROOT_SELECTOR = ":root"
private const val CSS_PROPERTY_PREFIX = "--qd-"

/**
 * Overrides the value of Quarkdown CSS properties.
 *
 * Each entry corresponds to a Quarkdown CSS property name and its value.
 * The names will be prefixed with `--qd-` to match the Quarkdown CSS variable naming convention.
 *
 * ```yaml
 * .cssproperties
 *   - background-color: green
 *   - main-font-size: 20px
 * ```
 *
 * For a complete list of properties, see the [global theme](https://github.com/iamgio/quarkdown/blob/main/quarkdown-html/src/main/scss/global.scss).
 * Unknown properties will be ignored.
 *
 * The content is wrapped in a `<style>` tag and rendered as-is,
 * without any additional processing or escaping, as long as the rendering target supports HTML.
 *
 * @param properties a dictionary of CSS property names and their values
 * @return a new [Html] node representing the style element
 * @permission [Permission.NativeContent] to inject native CSS properties
 * @throws com.quarkdown.core.permissions.MissingPermissionException if [Permission.NativeContent] is not granted
 * @wiki css
 */
@QFunction
@Name("cssproperties")
fun cssProperties(
    @Injected context: Context,
    properties: Map<String, Value<*>>,
) = css(
    context,
    buildString {
        append(CSS_ROOT_SELECTOR)
        append(" { ")
        properties.forEach { (name, value) ->
            append("$CSS_PROPERTY_PREFIX$name: ${value.unwrappedValue}; ")
        }
        append("}")
    },
)

/**
 * Generates an [llms.txt](https://llmstxt.org) index for the site.
 *
 * On every page, two directives are emitted:
 * - A visually hidden HTML paragraph (`<p class="sr-only">`) so agents crawling the HTML can find `llms.txt`.
 * - A Markdown blockquote, emitted only when the target is Markdown, carrying the same pointer.
 *
 * Placing this call in a shared setup file (such as `_setup.qd` in `docs` projects) makes both the
 * index generation and the per-page directive appear across the whole site.
 *
 * Requires [HtmlOptions.baseUrl] to be set via `.htmloptions`, since `llms.txt` must use absolute URLs.
 *
 * ```markdown
 * .llmstxt markdownavailable:{yes}
 *     My site's short description, used as the summary in llms.txt.
 * ```
 *
 * @param content short summary of the site, used as the blockquote at the top of `llms.txt`
 * @param isMarkdownMirrorAvailable whether the site also serves a Markdown counterpart for each page.
 *                            When `true`, the HTML directive also links to this page's raw Markdown counterpart,
 *                            computed automatically from the current subdocument.
 * @return a compound node containing both the HTML directive and the Markdown directive
 * @throws IllegalStateException if [HtmlOptions.baseUrl] is not set via `.htmloptions`
 * @wiki seo-aeo-optimization
 */
@QFunction
@Name("llmstxt")
fun llmsTxt(
    @Injected context: MutableContext,
    @Body content: String,
    @Name("markdownavailable") isMarkdownMirrorAvailable: Boolean,
): NodeValue {
    val baseUrl =
        checkNotNull(context.options.html.baseUrl) {
            "Cannot emit llms.txt directive: base URL is not set via .htmloptions baseurl:{...}"
        }

    val path = "$baseUrl/llms.txt"
    val markdownUrl = if (isMarkdownMirrorAvailable) getCurrentPageMarkdownUrl(context) else null

    context.options.html =
        context.options.html.copy(
            llmsTxtContent = content.trim(),
            isMarkdownMirrorAvailable = isMarkdownMirrorAvailable,
        )

    return AstGroup(
        listOf(
            Markdown("> For the complete documentation index, see [llms.txt]($path)."),
            Html(
                buildString {
                    append("<p class=\"sr-only\" data-hidden=\"\">")
                    append("For the complete documentation index, see <a href=\"$path\">llms.txt</a>.")
                    if (markdownUrl != null) {
                        append(" This page is also available as <a href=\"$markdownUrl\">Markdown</a>.")
                    }
                    append("</p>")
                },
            ),
        ),
    ).wrappedAsValue()
}

/**
 * Page-relative URL of the current subdocument's Markdown counterpart.
 * - Root: `index.md` sits next to `index.html`.
 * - Subdocument: `<name>.md` sits one directory above `<name>/index.html`.
 */
private fun getCurrentPageMarkdownUrl(context: Context): String {
    val name = context.subdocument.getOutputFileName(context).let(Escape.Url::escape)
    return when (context.subdocument) {
        Subdocument.Root -> "index.md"
        else -> "../$name.md"
    }
}
