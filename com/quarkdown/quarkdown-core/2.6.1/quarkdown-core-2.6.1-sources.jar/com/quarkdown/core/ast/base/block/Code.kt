package com.quarkdown.core.ast.base.block

import com.quarkdown.core.ast.InlineContent
import com.quarkdown.core.ast.attributes.localization.LocalizedKind
import com.quarkdown.core.ast.attributes.localization.LocalizedKindKeys
import com.quarkdown.core.ast.attributes.location.LocationTrackableNode
import com.quarkdown.core.ast.attributes.primitive.PrimitiveFunctionBackedNode
import com.quarkdown.core.ast.quarkdown.CaptionableNode
import com.quarkdown.core.ast.quarkdown.reference.CrossReferenceableNode
import com.quarkdown.core.function.dsl.functionCallArguments
import com.quarkdown.core.function.value.data.Range
import com.quarkdown.core.function.value.wrappedAsValue
import com.quarkdown.core.visitor.node.NodeVisitor

/**
 * A code block.
 * @param content code content
 * @param language optional syntax language
 * @param showLineNumbers whether to show line numbers
 * @param highlight whether to apply syntax highlighting
 * @param focusedLines range of lines to focus on (1-based). No lines are focused if `null`
 * @param callouts callout contents associated with line numbers (1-based)
 * @param caption optional caption
 * @param referenceId optional ID for cross-referencing via a [com.quarkdown.core.ast.quarkdown.reference.CrossReference]
 */
class Code(
    val content: String,
    val language: String?,
    val showLineNumbers: Boolean = true,
    val highlight: Boolean = true,
    val focusedLines: Range? = null,
    val callouts: Map<Int, String> = emptyMap(),
    override val caption: InlineContent? = null,
    override val referenceId: String? = null,
) : LocationTrackableNode,
    CrossReferenceableNode,
    CaptionableNode,
    LocalizedKind,
    PrimitiveFunctionBackedNode {
    override val kindLocalizationKey: String
        get() = LocalizedKindKeys.CODE_BLOCK

    override val backingFunctionName: String
        get() = "code"

    override fun toFunctionCallArguments() =
        functionCallArguments {
            arg("lang", string(language))
            arg("caption", inline(caption))
            arg("linenumbers", boolean(showLineNumbers))
            arg("focus", obj(focusedLines))
            arg(
                "callouts",
                dictionary(
                    callouts
                        .map { it.key.toString() to it.value.wrappedAsValue() }
                        .toMap(),
                ),
            )
            arg("ref", string(referenceId))
            arg("code", evaluable(content))
        }

    override fun <T> accept(visitor: NodeVisitor<T>) = visitor.visit(this)
}
