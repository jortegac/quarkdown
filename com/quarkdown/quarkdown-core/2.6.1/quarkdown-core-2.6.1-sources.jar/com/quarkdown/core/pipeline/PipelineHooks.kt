package com.quarkdown.core.pipeline

import com.quarkdown.core.ast.AstRoot
import com.quarkdown.core.function.library.Library
import com.quarkdown.core.lexer.Token
import com.quarkdown.core.pipeline.output.OutputResource

/**
 * Actions to run after each stage of a [Pipeline] has been completed.
 * @param afterRegisteringLibraries action to run after the libraries have been registered and are ready to be looked up (libraries as arguments)
 * @param afterLexing action to run after the tokens have been produced (output tokens as arguments)
 * @param afterParsing action to run after the AST has been generated (root as an argument)
 * @param afterExpanding action to run after the source-level function call queue has been expanded (root as an argument).
 *                       Further expansion may still happen during [afterTreeRewrite] if any `.extend` was registered:
 *                       use that hook when the consumer needs to observe the fully rewritten tree
 * @param afterTreeRewrite action to run after the AST rewrite has been completed (root as an argument)
 * @param afterTreeTraversal action to run after the produced AST has been visited
 * @param afterRendering action to run after the rendered output code has been generated (output code as an argument)
 * @param afterPostRendering action to run after the rendered output code has been manipulated (e.g. wrapped) (output code as an argument)
 * @param afterAllRendering action to run after all rendering has been completed.
 *                          It usually matches with [afterPostRendering].
 *                          If post-rendering is disabled, it will match with [afterRendering] instead.
 * @see Pipeline
 */
data class PipelineHooks(
    val afterRegisteringLibraries: Pipeline.(Set<Library>) -> Unit = {},
    val afterLexing: Pipeline.(Sequence<Token>) -> Unit = {},
    val afterParsing: Pipeline.(AstRoot) -> Unit = {},
    val afterExpanding: Pipeline.(AstRoot) -> Unit = {},
    val afterTreeRewrite: Pipeline.(AstRoot) -> Unit = {},
    val afterTreeTraversal: Pipeline.(AstRoot) -> Unit = {},
    val afterRendering: Pipeline.(CharSequence) -> Unit = {},
    val afterPostRendering: Pipeline.(CharSequence) -> Unit = {},
    val afterAllRendering: Pipeline.(CharSequence) -> Unit = {},
    val afterGeneratingResources: Pipeline.(Set<OutputResource>) -> Unit = {},
)
