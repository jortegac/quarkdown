package com.quarkdown.core.function

import com.quarkdown.core.function.call.FunctionCall
import com.quarkdown.core.function.call.binding.ArgumentBindings
import com.quarkdown.core.function.call.validate.FunctionCallValidator
import com.quarkdown.core.function.value.OutputValue

/**
 * A function that can be called from a Quarkdown source via a [FunctionCall].
 * @param T expected output type
 */
interface Function<T : OutputValue<*>> {
    /**
     * Function name.
     */
    val name: String

    /**
     * Declared parameters.
     */
    val parameters: List<FunctionParameter<*>>

    /**
     * Validators that check the validity of a function call towards this function.
     * If a condition is not met during the validation, an exception should be thrown.
     */
    val validators: List<FunctionCallValidator<T>>

    /**
     * Function that maps the input arguments into an output value.
     * Arguments and [parameters] compliance in terms of matching types and count is not checked here.
     * The [ArgumentBindings] allow looking up argument values by their parameter.
     *
     * - [ArgumentBindings]: bindings between parameters and arguments for the function call
     * - [FunctionCall]: the function call that triggered this invocation
     */
    val invoke: (ArgumentBindings, FunctionCall<T>) -> T
}

/**
 * A basic [Function] implementation.
 * @see Function
 */
data class SimpleFunction<T : OutputValue<*>>(
    override val name: String,
    override val parameters: List<FunctionParameter<*>>,
    override val validators: List<FunctionCallValidator<T>> = emptyList(),
    override val invoke: (ArgumentBindings, FunctionCall<T>) -> T,
) : Function<T>

fun Function<*>.signatureAsString(includeName: Boolean = true) =
    buildString {
        if (includeName) {
            append(name)
        }
        append("(")
        append(
            parameters.joinToString { parameter ->
                buildString {
                    if (parameter.isOptional) append("optional ")
                    parameter.type.simpleName?.let { append(it).append(" ") }
                    append(parameter.name)
                }
            },
        )
        append(")")
    }
