package com.quarkdown.core.document

/**
 * The theme of a document. A theme is defined by different components, hence allowing different combinations.
 * Components can also be not specified by setting them to `null`, and are hence ignored.
 * @param color color scheme component
 * @param layout layout format component
 */
data class DocumentTheme(
    val color: String?,
    val layout: String?,
) {
    /**
     * @return whether this theme has at least one component specified
     */
    val hasComponent: Boolean
        get() = color != null || layout != null
}

/**
 * Given [this] theme with nullable components, merges it with a default theme in order to fill in the missing components.
 * If [this] is `null` itself, the default theme is returned.
 * @param default default theme
 * @return a new theme with all components filled in, either from [this] (higher priority) or [default] (fill)
 */
fun DocumentTheme?.orDefault(default: DocumentTheme) =
    DocumentTheme(
        color = this?.color ?: default.color,
        layout = this?.layout ?: default.layout,
    )
