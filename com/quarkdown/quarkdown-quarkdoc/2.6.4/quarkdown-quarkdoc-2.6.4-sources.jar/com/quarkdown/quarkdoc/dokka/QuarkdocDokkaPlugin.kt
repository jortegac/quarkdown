package com.quarkdown.quarkdoc.dokka

import com.quarkdown.quarkdoc.dokka.index.DocsIndexCollectorTransformer
import com.quarkdown.quarkdoc.dokka.index.DocsIndexWriterPostAction
import com.quarkdown.quarkdoc.dokka.page.DocumentTypeConstraintsPageTransformer
import com.quarkdown.quarkdoc.dokka.page.LikelyChainedPageTransformer
import com.quarkdown.quarkdoc.dokka.page.PermissionsPageTransformer
import com.quarkdown.quarkdoc.dokka.page.WikiLinkPageTransformer
import com.quarkdown.quarkdoc.dokka.signature.QuarkdownSignatureProvider
import com.quarkdown.quarkdoc.dokka.transformers.enumeration.EnumParameterEntryListerTransformer
import com.quarkdown.quarkdoc.dokka.transformers.enumeration.EnumStorer
import com.quarkdown.quarkdoc.dokka.transformers.misc.DocumentTypeConstraintsTransformer
import com.quarkdown.quarkdoc.dokka.transformers.module.ModuleAsPackageTransformer
import com.quarkdown.quarkdoc.dokka.transformers.module.ModulesStorer
import com.quarkdown.quarkdoc.dokka.transformers.optional.AdditionalParameterPropertiesTransformer
import com.quarkdown.quarkdoc.dokka.transformers.suppress.SourceFunctionSuppressor
import com.quarkdown.quarkdoc.dokka.transformers.suppress.SuppressInjectedTransformer
import com.quarkdown.quarkdoc.dokka.transformers.type.ValueTypeTransformer
import org.jetbrains.dokka.CoreExtensions
import org.jetbrains.dokka.base.DokkaBase
import org.jetbrains.dokka.plugability.DokkaPlugin
import org.jetbrains.dokka.plugability.DokkaPluginApiPreview
import org.jetbrains.dokka.plugability.PluginApiPreviewAcknowledgement

/**
 * Dokka plugin that generates ad-hoc documentation for native Quarkdown functions.
 */
@Suppress("unused")
class QuarkdocDokkaPlugin : DokkaPlugin() {
    private val base by lazy { plugin<DokkaBase>() }

    /**
     * Stores the modules in which the functions are declared, to be used in [moduleAsPackageTransformer].
     * @see com.quarkdown.core.function.library.loader.Module
     */
    val modulesStorer by extending {
        base.preMergeDocumentableTransformer providing ::ModulesStorer order { before(moduleAsPackageTransformer) }
    }

    /**
     * Quarkdown modules, defined by a [com.quarkdown.core.function.library.loader.Module] property,
     * contain the functions declared in the same source file and are shown in the documentation as packages.
     * @see com.quarkdown.core.function.library.loader.Module
     */
    val moduleAsPackageTransformer by extending {
        base.preMergeDocumentableTransformer providing ::ModuleAsPackageTransformer
    }

    /**
     * Suppresses top-level source-side `@QFunction`s so only the KSP-generated wrappers
     * (which already carry exported names in their signature and rewritten KDoc) reach the docs.
     * @see com.quarkdown.quarkdoc.dokka.transformers.suppress.SourceFunctionSuppressor
     */
    val sourceFunctionSuppressor by extending {
        base.preMergeDocumentableTransformer providing ::SourceFunctionSuppressor order {
            before(moduleAsPackageTransformer)
        }
    }

    /**
     * Renames references of [com.quarkdown.core.function.value.Value], and subclasses, in the signature
     * to a more human-readable form.
     */
    val valueTypeTransformer by extending {
        base.preMergeDocumentableTransformer providing ::ValueTypeTransformer
    }

    /**
     * Parameters annotated with `@Injected` are hidden (suppressed) in the generated documentation.
     * @see com.quarkdown.core.function.reflect.annotation.Injected
     */
    val suppressInjectedTransformer by extending {
        base.preMergeDocumentableTransformer providing ::SuppressInjectedTransformer
    }

    /**
     * Stores enum declarations, to be used in [enumParameterEntryListerTransformer].
     */
    val enumStorer by extending {
        base.preMergeDocumentableTransformer providing ::EnumStorer order {
            before(enumParameterEntryListerTransformer)
        }
    }

    /**
     * Lists enum entries in the documentation for parameters that expect an enum.
     */
    val enumParameterEntryListerTransformer by extending {
        base.preMergeDocumentableTransformer providing ::EnumParameterEntryListerTransformer
    }

    val additionalParameterPropertiesTransformer by extending {
        base.preMergeDocumentableTransformer providing ::AdditionalParameterPropertiesTransformer
    }

    /**
     * Given a function annotated with `@OnlyForDocumentType` which defines constraints
     * about the document type the function supports, this transformer stores this data
     * for [documentTypeConstraintsPageTransformer] to display it.
     * @see com.quarkdown.core.function.reflect.annotation.OnlyForDocumentType
     */
    val documentPositiveTypeConstraintsTransformer by extending {
        base.preMergeDocumentableTransformer providing DocumentTypeConstraintsTransformer::Positive
    }

    /**
     * Like [documentPositiveTypeConstraintsTransformer] but for the negative case, via `@NotForDocumentType`.
     * @see com.quarkdown.core.function.reflect.annotation.NotForDocumentType
     */
    val documentNegativeTypeConstraintsTransformer by extending {
        base.preMergeDocumentableTransformer providing DocumentTypeConstraintsTransformer::Negative
    }

    /**
     * Displays the document type constraints produced by [documentTypeConstraintsTransformer] in the documentation.
     */
    val documentTypeConstraintsPageTransformer by extending {
        CoreExtensions.pageTransformer providing ::DocumentTypeConstraintsPageTransformer
    }

    /**
     * Generates a new section for likely chained functions.
     */
    val likelyChainedPageTransformer by extending {
        CoreExtensions.pageTransformer providing ::LikelyChainedPageTransformer
    }

    /**
     * Generates a new section listing the permissions required by a function, from `@permission` tags.
     */
    val permissionsPageTransformer by extending {
        CoreExtensions.pageTransformer providing ::PermissionsPageTransformer order {
            after(likelyChainedPageTransformer)
        }
    }

    /**
     * Generates a new section for the `@wiki` documentation tag with a link to the corresponding wiki page.
     */
    val wikiLinkPageTransformer by extending {
        CoreExtensions.pageTransformer providing ::WikiLinkPageTransformer order {
            after(permissionsPageTransformer)
        }
    }

    /**
     * Collects the documentation index data of module functions from the Dokka model,
     * after parameter documentation is finalized.
     */
    val docsIndexCollector by extending {
        base.preMergeDocumentableTransformer providing ::DocsIndexCollectorTransformer order {
            after(moduleAsPackageTransformer)
            after(suppressInjectedTransformer)
            after(enumParameterEntryListerTransformer)
            after(additionalParameterPropertiesTransformer)
        }
    }

    /**
     * Writes the documentation index to the output directory after rendering.
     */
    val docsIndexWriter by extending {
        CoreExtensions.postActions providing ::DocsIndexWriterPostAction
    }

    /**
     * Generates Quarkdown signatures for functions in Quarkdown modules.
     */
    val signatureProvider by extending {
        base.signatureProvider providing ::QuarkdownSignatureProvider override base.kotlinSignatureProvider
    }

    @DokkaPluginApiPreview
    override fun pluginApiPreviewAcknowledgement() = PluginApiPreviewAcknowledgement
}
