package com.quarkdown.lsp.hover.function

import com.quarkdown.lsp.TextDocument
import com.quarkdown.lsp.cache.DocumentedFunction
import com.quarkdown.lsp.cache.functionCalls
import com.quarkdown.lsp.documentation.DocsIndexSource
import com.quarkdown.lsp.documentation.getDocumentation
import com.quarkdown.lsp.hover.HoverSupplier
import com.quarkdown.lsp.model.CursorPosition
import com.quarkdown.lsp.model.HoverInfo
import com.quarkdown.lsp.tokenizer.FunctionCall
import com.quarkdown.lsp.tokenizer.FunctionCallToken
import com.quarkdown.lsp.tokenizer.getAtSourceIndex
import com.quarkdown.lsp.tokenizer.getTokenAtSourceIndex
import com.quarkdown.lsp.util.toOffset

/**
 * Provider of documentation on hover for function calls.
 * @property docs the source of the documentation index
 */
class FunctionDocumentationHoverSupplier(
    private val docs: DocsIndexSource,
) : HoverSupplier {
    override fun getHover(
        position: CursorPosition,
        document: TextDocument,
    ): HoverInfo? {
        val text = document.text

        // Gets the function call at the specified hover position.
        val index = position.toOffset(text)
        val call: FunctionCall =
            document.functionCalls
                .getAtSourceIndex(index)
                ?: return null

        // If the hover position is over a function name in the chain, shows documentation for that specific function.
        // Otherwise, shows documentation for the last function in the chain.
        val nameToken: FunctionCallToken? =
            call
                .getTokenAtSourceIndex(index)
                ?.takeIf { it.type == FunctionCallToken.Type.FUNCTION_NAME }

        // Returns the documentation to display in the hover.
        val function: DocumentedFunction =
            getDocumentation(docs, nameToken?.lexeme ?: call.lastChainedName)
                ?: return null

        return function.documentationMarkdown?.let(::HoverInfo)
    }
}
