package com.quarkdown.lsp

import com.quarkdown.lsp.cache.CacheableFunctionCatalogue
import com.quarkdown.lsp.completion.CompletionSuppliersFactory
import com.quarkdown.lsp.diagnostics.DiagnosticsSuppliersFactory
import com.quarkdown.lsp.documentation.DirectoryDocsIndexSource
import com.quarkdown.lsp.documentation.DocsIndexSource
import com.quarkdown.lsp.highlight.SemanticTokensSuppliersFactory
import com.quarkdown.lsp.highlight.TokenType
import com.quarkdown.lsp.hover.HoverSuppliersFactory
import com.quarkdown.lsp.ontype.OnTypeFormattingSuppliersFactory
import com.quarkdown.lsp.pattern.QuarkdownPatterns
import org.eclipse.lsp4j.CompletionOptions
import org.eclipse.lsp4j.Diagnostic
import org.eclipse.lsp4j.DocumentOnTypeFormattingOptions
import org.eclipse.lsp4j.InitializeParams
import org.eclipse.lsp4j.InitializeResult
import org.eclipse.lsp4j.MessageParams
import org.eclipse.lsp4j.MessageType
import org.eclipse.lsp4j.PublishDiagnosticsParams
import org.eclipse.lsp4j.SemanticTokensLegend
import org.eclipse.lsp4j.SemanticTokensWithRegistrationOptions
import org.eclipse.lsp4j.ServerCapabilities
import org.eclipse.lsp4j.TextDocumentSyncKind
import org.eclipse.lsp4j.jsonrpc.messages.Either
import org.eclipse.lsp4j.services.LanguageClient
import org.eclipse.lsp4j.services.LanguageClientAware
import org.eclipse.lsp4j.services.LanguageServer
import org.eclipse.lsp4j.services.TextDocumentService
import org.eclipse.lsp4j.services.WorkspaceService
import java.io.File
import java.util.concurrent.CompletableFuture
import java.util.concurrent.Executor
import java.util.concurrent.ForkJoinPool
import kotlin.system.exitProcess

/**
 * Quarkdown Language Server implementation.
 * @param quarkdownDirectory the directory containing the Quarkdown distribution, if available
 * @param executor executor used to dispatch background work (catalogue warm-up, diagnostics, completion)
 * @param onExit hook invoked when the client sends the LSP `exit` notification. Defaults to
 *               terminating the JVM, which is appropriate for stdio mode
 */
class QuarkdownLanguageServer(
    private val quarkdownDirectory: File?,
    private val executor: Executor = ForkJoinPool.commonPool(),
    private val onExit: () -> Unit = { exitProcess(0) },
) : LanguageServer,
    LanguageClientAware {
    private val textDocumentService: TextDocumentService =
        QuarkdownTextDocumentService(
            this,
            executor,
            CompletionSuppliersFactory.default(this),
            SemanticTokensSuppliersFactory.default(),
            HoverSuppliersFactory.default(this),
            DiagnosticsSuppliersFactory.default(this),
            OnTypeFormattingSuppliersFactory.default(),
        )

    private val completionTriggers =
        with(QuarkdownPatterns.FunctionCall) {
            listOf(
                BEGIN,
                CHAIN_SEPARATOR.last().toString(),
                ARGUMENT_BEGIN,
            )
        }

    private val onTypeFormattingOptions = DocumentOnTypeFormattingOptions("\n")

    private val workspaceService: WorkspaceService = QuarkdownWorkspaceService(this)

    private lateinit var client: LanguageClient

    /**
     * The directory containing the documentation files, if available.
     * This is located in the Quarkdown distribution.
     */
    private val docsDirectory: File?
        get() = quarkdownDirectory?.resolve("docs")?.takeIf { it.isDirectory }

    /**
     * The source of the documentation index, if available, backed by [docsDirectory].
     */
    val docsIndexSource: DocsIndexSource?
        get() = docsDirectory?.let(::DirectoryDocsIndexSource)

    /**
     * @return the source of the documentation index, or throws an exception if it's not available
     * @throws IllegalStateException if the documentation directory does not exist
     */
    fun docsIndexSourceOrThrow(): DocsIndexSource = requireNotNull(docsIndexSource) { "Documentation directory is not available" }

    override fun initialize(params: InitializeParams?): CompletableFuture<InitializeResult?>? {
        val legend =
            SemanticTokensLegend(
                TokenType.legend,
                emptyList(),
            )

        val serverCaps =
            ServerCapabilities().apply {
                textDocumentSync = Either.forLeft(TextDocumentSyncKind.Full)
                completionProvider = CompletionOptions(true, completionTriggers)
                hoverProvider = Either.forLeft(true)
                semanticTokensProvider = SemanticTokensWithRegistrationOptions(legend, true, null)
                documentOnTypeFormattingProvider = onTypeFormattingOptions
            }
        val response = InitializeResult(serverCaps)

        // Caching the available function catalogue for improved performance.
        docsIndexSource?.let { docs ->
            executor.execute { CacheableFunctionCatalogue.storeCatalogue(docs) }
        }

        return CompletableFuture.completedFuture(response)
    }

    override fun shutdown(): CompletableFuture<in Any>? = CompletableFuture.completedFuture(null)

    override fun exit() = onExit()

    override fun getTextDocumentService() = textDocumentService

    override fun getWorkspaceService() = workspaceService

    override fun connect(client: LanguageClient?) {
        this.client = client ?: throw IllegalStateException("Language client cannot be null")
    }

    /**
     * Publishes diagnostics to the client.
     * @param uri the document URI
     * @param diagnostics the list of diagnostics
     */
    fun publishDiagnostics(
        uri: String,
        diagnostics: List<Diagnostic>,
    ) {
        client.publishDiagnostics(PublishDiagnosticsParams(uri, diagnostics))
    }

    /**
     * Logs a message to the client.
     * @param message the message to log
     */
    fun log(message: String) {
        client.logMessage(MessageParams(MessageType.Log, message))
    }
}
